> **DOCUMENTO INVENTATO A SCOPO DIDATTICO — non corrisponde a un avviso reale.**

# Avviso dell'ufficio tecnico (inventato)

**Laboratorio Informatica 2 chiuso per manutenzione mercoledì 15 e giovedì 16 ottobre 2025.**

Si sostituiscono i computer di sei postazioni. Le prenotazioni già segnate per il Laboratorio
Informatica 2 in quei due giorni vanno spostate in un altro laboratorio o in un altro giorno.
Per informazioni: ufficiotecnico@itistdimostrativo.demo.invalid.
