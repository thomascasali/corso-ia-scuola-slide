# Istruzioni per questa cartella

- Questa è una cartella di prova dell'Istituto Tecnico Dimostrativo, una scuola inventata.
  Tutti i dati (prenotazioni, classi, docenti) sono inventati.
- Rispondi in italiano semplice: chi legge non è un tecnico.
- Non modificare `prenotazioni-laboratori-ottobre-2025.csv`, `regolamento-uso-laboratori-breve.md`
  né `avviso-manutenzione.md`: sono le fonti. Puoi creare file nuovi.
- Prima di dire che una prenotazione va bene, controllala contro il regolamento e contro
  l'avviso di manutenzione: un laboratorio chiuso non può ospitare nessuna prenotazione, anche
  se il file delle prenotazioni non lo segnala.
- Non inviare niente a nessuno.
