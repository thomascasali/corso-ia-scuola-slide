> **DOCUMENTO INVENTATO A SCOPO DIDATTICO — non corrisponde a regole reali dell'istituto.**
> L'"Istituto Tecnico Dimostrativo" non esiste. Numeri e orari sono stati scelti per le
> esercitazioni del corso.

# Istituto Tecnico Dimostrativo

## Regolamento breve per l'uso dei laboratori

Anno scolastico dimostrativo 2025/2026.

### Art. 1 – Orario di apertura

I laboratori (Informatica 1, Informatica 2, Linguistico) sono prenotabili dal lunedì al
venerdì, dalle 8:00 alle 17:00. Fuori da questo orario nessuna prenotazione è valida.

### Art. 2 – Durata delle prenotazioni

Ogni prenotazione dura almeno 1 ora e al massimo 2 ore consecutive per la stessa classe.

### Art. 3 – Un laboratorio, una classe alla volta

Lo stesso laboratorio non può essere prenotato da due classi diverse nella stessa fascia
oraria, nemmeno in parte: chi prenota per secondo deve scegliere un altro orario o un altro
laboratorio.

### Art. 4 – Chiusure per manutenzione

Quando un laboratorio è chiuso per manutenzione, lo comunica un avviso dell'ufficio tecnico.
Le prenotazioni già fatte per quel periodo non sono valide e vanno spostate, anche se compaiono
ancora nell'elenco delle prenotazioni.

### Art. 5 – Come si prenota

Le richieste di prenotazione si inviano a laboratori@itistdimostrativo.demo.invalid almeno un
giorno prima.
