---
name: controllo-adesioni
description: Procedura della scuola per controllare i moduli di adesione a un'uscita (visita guidata o viaggio) rispetto all'elenco della classe e ai versamenti, rinominare i moduli, mettere da parte quelli incompleti e preparare il riepilogo. Usala ogni volta che il compito riguarda i moduli di adesione, l'elenco della classe o i versamenti della quota.
---

# Controllo dei moduli di adesione

Procedura della segreteria dell'Istituto Tecnico Dimostrativo (scuola inventata).
Seguila un passo alla volta.

1. **Leggi tutto.** Apri l'elenco della classe, i versamenti e ogni modulo. I moduli hanno
   nomi di file disordinati (scan, foto, mail salvate): il nome del file non dice niente,
   conta quello che c'è scritto dentro. Se esiste una cartella `in-arrivo`, contiene moduli
   non ancora trattati: non toccarla finché la persona non lo chiede.
2. **Decidi lo stato di ogni modulo** con questi criteri:
   - `valido`: classe 4ª Y, firma del genitore presente, lo studente partecipa;
   - `senza-firma`: la firma manca o è vuota;
   - `non-partecipa`: il genitore ha scritto che lo studente non partecipa;
   - `altra-classe`: lo studente non è nell'elenco della classe 4ª Y;
   - `doppio`: lo stesso studente ha già un altro modulo (tieni come valido il primo, lascia
     l'altro con questo stato, non buttarlo).
   Una mail del genitore con autorizzazione e nome in fondo vale come modulo firmato.
   Se un caso non rientra in questi criteri, scrivilo tra i dubbi: non decidere tu.
3. **Rinomina** ogni modulo come `Cognome-Nome-stato` (per esempio `Rossi-Mario-valido.txt`).
   Prima di rinominare e spostare chiedi il permesso. Non cancellare niente.
4. **Sposta** nella cartella `da-sollecitare` i moduli con stato `senza-firma`. Gli altri
   restano dove sono. Gli studenti dell'elenco senza nessun modulo non hanno un file da
   spostare: vanno nel riepilogo.
5. **Versamenti.** Per ogni studente guarda se compare in `versamenti-4Y.csv`. Il pagamento
   dichiarato nel modulo non è una prova: conta il file dei versamenti. La mancanza della
   quota non rende nullo il modulo, ma va scritta.
6. **Scrivi il riepilogo** in `riepilogo-adesioni.md`: una riga per ogni studente
   dell'elenco (cognome, nome, stato, file, quota versata sì/no); il numero di adesioni
   valide; la soglia (art. 5 del regolamento: 71% degli iscritti, arrotondato per eccesso)
   e se è raggiunta; una sezione "Da decidere" con i casi dubbi.
7. **Controllo finale.** Verifica con un piccolo programma, senza fare i conti a mente:
   - ogni studente dell'elenco compare una volta sola nel riepilogo;
   - i file nelle cartelle sono tanti quanti i moduli ricevuti e corrispondono alle righe
     del riepilogo;
   - le adesioni valide sommate ai restanti stati tornano al totale.
   Se qualcosa non torna, correggi prima di consegnare.
8. **Dichiara i limiti.** Scrivi cosa non hai potuto verificare (per esempio: firme vere o
   false, bonifici non presenti nel file dei versamenti, moduli letti solo come testo).
